<?php
/**
 * Hello! Pro - Navigation menus
 *
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://my.studiopress.com/themes/genesis-sample/
 */
/**
 * Supported Genesis navigation menus.
 */
return array(
	'primary'   => __( 'Header Menu', 'hello-pro' ),
	'secondary' => __( 'Footer Menu', 'hello-pro' ),
);
