<?php
/**
 * Hello! Pro - One-Click Theme Setup - Sample Blog post content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Hello! Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget eros vitae est vehicula vulputate. In aliquet bibendum placerat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nullam eu massa vehicula, tincidunt ipsum vitae, porta massa. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec rutrum, sem ac cursus viverra, purus lacus cursus erat, ultrices tempor nunc urna vel lacus. Etiam facilisis sit amet magna sit amet lacinia. Nunc semper mi mauris, vitae convallis mi mollis non. Pellentesque ac magna metus. Donec hendrerit interdum neque. Vestibulum vitae varius odio. Aenean at dapibus libero, non finibus massa. Nam volutpat, justo iaculis imperdiet lacinia, ex sapien suscipit augue, sed consectetur erat orci sed turpis. Maecenas at risus pretium, iaculis est nec, iaculis sapien. Suspendisse ornare ac libero et cursus. Pellentesque maximus ante vitae accumsan suscipit.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Proin sagittis ultrices mi. Quisque vitae elementum nibh, at euismod quam. Etiam at mauris congue nunc facilisis aliquet in sed est. Donec laoreet sapien nisi, eu dignissim massa egestas eleifend. Nullam quis mi sed nisi ultrices maximus non et quam. Ut ante nulla, suscipit ac consequat vel, hendrerit eget sapien. Nam sodales ac quam non dignissim. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris non risus in magna commodo sagittis vel vitae quam. Proin velit urna, maximus nec aliquet non, volutpat et ex.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Mauris vel vehicula leo, a ultricies metus. Aenean mollis magna id tellus sodales, nec faucibus nunc pellentesque. Pellentesque dictum nisi augue, non posuere nulla mattis in. Quisque eleifend sed dolor vitae suscipit. Integer consequat a ipsum ac aliquam. Donec dictum sodales ante vitae suscipit. Vestibulum nisl dolor, convallis ac commodo nec, vehicula id tortor. Duis venenatis aliquet tortor ut facilisis. Aliquam dolor libero, efficitur ac iaculis non, sollicitudin vitae nisl. Suspendisse consequat risus et ligula consectetur luctus. Nulla vel dictum odio.</p>
<!-- /wp:paragraph -->
CONTENT;
