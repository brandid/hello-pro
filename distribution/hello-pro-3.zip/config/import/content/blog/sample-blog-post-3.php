<?php
/**
 * Hello! Pro - One-Click Theme Setup - Sample Blog post content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Hello! Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae porta libero, id placerat urna. Cras in neque non nibh sagittis ultrices condimentum vel est. Fusce facilisis neque eu diam condimentum, quis dignissim ligula imperdiet. Curabitur eu eleifend augue. Vivamus sollicitudin nec tellus interdum interdum. Maecenas elementum ex eu lectus vestibulum tincidunt. Mauris vel lacinia eros. In et nisl sem. Suspendisse lobortis mauris ut ante semper tincidunt. Proin eleifend leo nulla, sit amet venenatis urna sodales pellentesque. Morbi in sollicitudin est, nec ultricies mi.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In mollis, nisi non malesuada fringilla, dui quam maximus lacus, eget lacinia mauris magna vitae turpis. Sed aliquet tempus libero. Vivamus ultrices tellus vitae ullamcorper sagittis. In ut molestie enim, vel volutpat risus. Fusce fringilla non orci non eleifend. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed tempus nec nunc sit amet gravida. Ut et felis quis dolor vehicula tincidunt.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Pellentesque sed est nibh. Quisque aliquam vel erat eu convallis. Ut sed nulla at dolor ornare congue id vitae massa. Donec turpis ipsum, rhoncus sit amet consequat ut, auctor non risus. Nam sodales turpis et turpis tincidunt blandit. Vestibulum tempus tincidunt mauris a pharetra. Phasellus consequat accumsan hendrerit. Nam nec bibendum mi. Aliquam leo nisi, blandit nec cursus in, eleifend in lectus. Integer ultricies leo diam, id aliquam arcu molestie nec. Aliquam erat volutpat. Ut augue dui, pretium et metus a, bibendum egestas ante.</p>
<!-- /wp:paragraph -->
CONTENT;
