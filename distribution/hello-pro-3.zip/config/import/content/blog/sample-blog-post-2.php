<?php
/**
 * Hello! Pro - One-Click Theme Setup - Sample Blog post content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Hello! Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras faucibus a eros sit amet sodales. Nunc tincidunt fermentum eros id aliquet. Fusce vehicula justo neque, ut malesuada eros pharetra vel. Nulla quis consequat nunc. Vivamus hendrerit eros vitae nibh suscipit elementum. In euismod cursus eros, sed dictum sapien porttitor eu. In hac habitasse platea dictumst. Ut pretium sed quam vitae laoreet. Proin vitae massa sit amet ligula scelerisque aliquam eu dapibus leo. Aliquam placerat et urna non tincidunt. In ligula magna, sagittis quis enim quis, vulputate commodo dolor. Nullam quis dolor sem. Sed elit orci, iaculis sit amet semper eget, faucibus quis libero. Ut nisl augue, tempus a eros ac, molestie imperdiet neque.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Cras viverra lorem nibh, nec facilisis metus posuere quis. Vivamus laoreet maximus sapien, a vulputate turpis tristique in. Cras suscipit molestie tellus sed ultricies. Nunc sed odio tincidunt, iaculis lorem tempus, varius dui. Suspendisse ut scelerisque ex. Fusce in justo condimentum, pellentesque sapien id, dapibus metus. Mauris id dolor a nulla fringilla accumsan. Nam vel ante egestas, posuere est non, tempor nibh. In consectetur laoreet lacus ac lacinia. Cras dolor quam, ornare sed dictum nec, placerat eu ex. Quisque non sem venenatis, tempor nunc ut, iaculis erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In condimentum vel nisl id iaculis. Suspendisse mollis, tortor a pellentesque fermentum, justo massa posuere nisi, eu iaculis ex erat eu elit.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nam scelerisque lectus vel lorem pulvinar, et vulputate metus molestie. Quisque eget quam nec lorem laoreet tempor in sed enim. Quisque sed imperdiet sem. Suspendisse sed sodales turpis. Etiam eu neque volutpat, placerat massa vitae, dignissim urna. Fusce at gravida nulla. In varius diam a tortor vehicula efficitur quis nec quam. Maecenas porta risus nec viverra accumsan. Aliquam in commodo nulla. Curabitur eget suscipit nisl, ut consequat tortor. Vestibulum eu leo in lorem pulvinar dapibus.</p>
<!-- /wp:paragraph -->
CONTENT;
