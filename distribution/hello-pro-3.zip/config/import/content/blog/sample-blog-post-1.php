<?php
/**
 * Hello! Pro- One-Click Theme Setup - Sample Blog post content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Hello! Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
<!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras molestie eget mauris nec mattis. Pellentesque interdum egestas eros in ornare. Nulla iaculis ultricies est ac interdum. Ut ipsum urna, condimentum nec tristique a, semper a magna. Integer eget sem id ipsum luctus porttitor sit amet et nunc. Pellentesque aliquet metus vel felis interdum, et dapibus urna malesuada. Aliquam in lacinia enim. Phasellus egestas nibh ac lectus tincidunt, ac ullamcorper lectus aliquet. Nunc at varius odio. Donec eu nulla hendrerit, faucibus urna ac, molestie sapien. Mauris ipsum augue, maximus id ante iaculis, ornare porta tortor. Suspendisse porta ante mi. Morbi varius vel urna vitae sagittis. Aliquam iaculis nisl ultrices dignissim sodales. Duis cursus fermentum mauris eget dignissim. Nullam aliquet augue eu lectus ultricies venenatis.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Cras ultricies vestibulum dignissim. Proin ex urna, porta pharetra arcu id, vehicula mattis nunc. Donec malesuada tortor sed arcu lobortis, id pharetra nisl tincidunt. Pellentesque tempor odio enim, porta sagittis risus suscipit quis. Aenean sit amet suscipit neque, et tempus lectus. Etiam ornare malesuada sapien, ac ultricies lacus tincidunt id. Nunc ac neque vitae arcu efficitur condimentum et id lectus. Donec pharetra, elit ultricies sollicitudin vehicula, nulla lectus lacinia neque, in efficitur arcu lorem ut eros. Pellentesque ullamcorper ut libero imperdiet dapibus. Suspendisse luctus vitae dui at viverra. Morbi sit amet nibh diam. Quisque in rhoncus massa. Pellentesque maximus sagittis molestie. Curabitur consequat orci enim, at imperdiet sem pellentesque vel. Duis varius id dolor non molestie.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nunc malesuada pharetra aliquam. Quisque non magna in massa rhoncus congue vel vitae diam. Sed turpis nulla, dictum eget tincidunt vel, porttitor et dui. Phasellus efficitur nibh magna, molestie facilisis felis efficitur a. In hac habitasse platea dictumst. Vivamus non porttitor tortor. Suspendisse purus purus, porta non lectus sed, pretium ultricies odio. Vivamus ex lorem, dapibus eget bibendum et, auctor sed velit.<br></p>
<!-- /wp:paragraph -->
CONTENT;
