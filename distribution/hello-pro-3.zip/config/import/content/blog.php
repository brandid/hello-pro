<?php
/**
 * Hello! Pro - Demo BLOG page One-Click Theme Setup content
 *
 * This page intentionally left blank -- page content does not display on the
 * assigned Archive page.
 *
 * @package Hello Pro
 * @author  StudioPress
 * @license GPL-2.0-or-later
 * @link    https://www.studiopress.com/
 */

return <<<CONTENT
CONTENT;
