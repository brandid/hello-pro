# Hello Pro 3 Theme Changelog

## Changelog

### 3.0.2 - (Apr 8, 2019)
* We've added a new "Footer Menu" to the One-Click Demo Install, added page template files, and improved styling for Gutenberg.

### 3.0.1 - (Mar 22, 2019)
Requires Genesis 2.9.0+.
* Package for Initial Release
